# calc

Simple calculator written in C++
